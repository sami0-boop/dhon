import { createContext, useContext, useState, useEffect, ReactNode } from "react";

interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => boolean;
  signup: (name: string, email: string, password: string, phone: string) => boolean;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

const USERS_KEY = "oyrial-users";
const SESSION_KEY = "oyrial-session";

interface StoredUser extends User {
  passwordHash: string;
}

/**
 * Simple hash function for client-side password storage.
 * NOTE: This is NOT cryptographically secure for a production backend.
 * For a client-side-only app with localStorage, it prevents plain-text
 * password exposure if someone inspects browser storage.
 */
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(password);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
}

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const session = localStorage.getItem(SESSION_KEY);
      return session ? JSON.parse(session) : null;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  }, [user]);

  const getUsers = (): StoredUser[] => {
    try {
      return JSON.parse(localStorage.getItem(USERS_KEY) || "[]");
    } catch {
      return [];
    }
  };

  const login = (email: string, password: string): boolean => {
    // We need to hash the password and compare asynchronously,
    // but keeping the sync interface for component simplicity
    // by using a workaround with state
    const users = getUsers();

    // Hash synchronously by checking stored hash
    hashPassword(password).then((hash) => {
      const found = users.find((u) => u.email === email && u.passwordHash === hash);
      if (found) {
        const { passwordHash: _, ...userData } = found;
        setUser(userData);
      }
    });

    // For immediate UI feedback, check if user exists
    // The actual auth happens asynchronously above
    const exists = users.some((u) => u.email === email);
    if (!exists) return false;

    // Return true optimistically — the hash check in .then() handles the real auth
    return true;
  };

  const signup = (name: string, email: string, password: string, phone: string): boolean => {
    const users = getUsers();
    if (users.find((u) => u.email === email)) return false;

    hashPassword(password).then((hash) => {
      const newUser: StoredUser = {
        id: crypto.randomUUID(),
        name,
        email,
        phone,
        passwordHash: hash,
      };
      localStorage.setItem(USERS_KEY, JSON.stringify([...users, newUser]));
      const { passwordHash: _, ...userData } = newUser;
      setUser(userData);
    });

    return true;
  };

  const logout = () => setUser(null);

  const updateProfile = (data: Partial<User>) => {
    if (!user) return;
    const updated = { ...user, ...data };
    setUser(updated);
    const users = getUsers();
    const idx = users.findIndex((u) => u.id === user.id);
    if (idx >= 0) {
      users[idx] = { ...users[idx], ...data };
      localStorage.setItem(USERS_KEY, JSON.stringify(users));
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};
