import React, { createContext, useContext, useState, ReactNode, useEffect } from "react";
import { products as initialProducts, Product } from "@/data/products";

export type OrderStatus = "Processing" | "Shipped" | "Delivered" | "Cancelled";

export interface Order {
  id: string;
  customerName: string;
  total: number;
  status: OrderStatus;
  date: string;
  items: { productName: string; quantity: number }[];
}

interface StoreContextType {
  // Auth
  isAuthenticated: boolean;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  // Catalog
  catalog: Product[];
  updateProduct: (updatedProduct: Product) => void;
  addProduct: (product: Product) => void;
  deleteProduct: (id: string) => void;
  // Orders
  orders: Order[];
  updateOrderStatus: (id: string, status: OrderStatus) => void;
  addOrder: (order: Order) => void;
}

const StoreContext = createContext<StoreContextType | undefined>(undefined);

// Mock initial orders
const MOCK_ORDERS: Order[] = [
  { id: "ORD-1092", customerName: "Sarah Rahman", total: 2500, status: "Processing", date: new Date().toISOString(), items: [{ productName: "Oyrial No. 01", quantity: 1 }] },
  { id: "ORD-1090", customerName: "Fahim Ahmed", total: 5600, status: "Shipped", date: new Date(Date.now() - 86400000).toISOString(), items: [{ productName: "Oyrial No. 02", quantity: 2 }] },
  { id: "ORD-1088", customerName: "Nafis Kamal", total: 3200, status: "Delivered", date: new Date(Date.now() - 172800000).toISOString(), items: [{ productName: "Oyrial No. 03", quantity: 1 }] },
];

export const StoreProvider = ({ children }: { children: ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [catalog, setCatalog] = useState<Product[]>(initialProducts);

  useEffect(() => {
    // Auth persistence
    const session = localStorage.getItem("oyrial_admin_auth");
    if (session === "true") setIsAuthenticated(true);
    
    // Catalog persistence
    const savedCatalog = localStorage.getItem("oyrial_admin_catalog");
    if (savedCatalog) {
      setCatalog(JSON.parse(savedCatalog));
    }

    // Orders persistence
    const savedOrders = localStorage.getItem("oyrial_admin_orders");
    if (savedOrders) {
      setOrders(JSON.parse(savedOrders));
    }
  }, []);

  const login = (email: string, password: string) => {
    if (email === "admin@brand.com" && password === "admin123") {
      setIsAuthenticated(true);
      localStorage.setItem("oyrial_admin_auth", "true");
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem("oyrial_admin_auth");
  };

  const updateProduct = (updatedProduct: Product) => {
    const newCatalog = catalog.map(p => p.id === updatedProduct.id ? updatedProduct : p);
    setCatalog(newCatalog);
    localStorage.setItem("oyrial_admin_catalog", JSON.stringify(newCatalog));
  };

  const addProduct = (p: Product) => {
    const newCatalog = [...catalog, p];
    setCatalog(newCatalog);
    localStorage.setItem("oyrial_admin_catalog", JSON.stringify(newCatalog));
  };

  const deleteProduct = (id: string) => {
    const newCatalog = catalog.filter(p => p.id !== id);
    setCatalog(newCatalog);
    localStorage.setItem("oyrial_admin_catalog", JSON.stringify(newCatalog));
  };

  const updateOrderStatus = (id: string, status: OrderStatus) => {
    const newOrders = orders.map(o => (o.id === id ? { ...o, status } : o));
    setOrders(newOrders);
    localStorage.setItem("oyrial_admin_orders", JSON.stringify(newOrders));
  };

  const addOrder = (order: Order) => {
    const newOrders = [order, ...orders];
    setOrders(newOrders);
    localStorage.setItem("oyrial_admin_orders", JSON.stringify(newOrders));
  };

  return (
    <StoreContext.Provider value={{ 
      isAuthenticated, login, logout, 
      catalog, updateProduct, addProduct, deleteProduct,
      orders, updateOrderStatus, addOrder 
    }}>
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => {
  const context = useContext(StoreContext);
  if (!context) throw new Error("useStore must be used within a StoreProvider");
  return context;
};
