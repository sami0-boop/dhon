import { Link } from "react-router-dom";
import { Instagram, Facebook, MessageCircle } from "lucide-react";

const Footer = () => (
  <footer className="bg-oyrial-charcoal text-oyrial-offwhite py-16">
    <div className="container">
      <div className="flex flex-col md:flex-row items-center justify-between gap-8">
        <Link to="/" className="font-serif text-2xl tracking-wider">
          Oyrial
        </Link>
        <div className="flex items-center gap-6 text-sm text-oyrial-muted">
          <a
            href="https://instagram.com/oyrial"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-oyrial-offwhite transition-colors flex items-center gap-1.5"
          >
            <Instagram size={16} />
            Instagram
          </a>
          <a
            href="https://www.facebook.com/share/18eU4nouYx/"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-oyrial-offwhite transition-colors flex items-center gap-1.5"
          >
            <Facebook size={16} />
            Facebook
          </a>
          <a
            href="https://wa.me/8801609573884"
            target="_blank"
            rel="noopener noreferrer"
            className="hover:text-oyrial-offwhite transition-colors flex items-center gap-1.5"
          >
            <MessageCircle size={16} />
            WhatsApp
          </a>
          <a href="mailto:oyriall@gmail.com" className="hover:text-oyrial-offwhite transition-colors">
            oyriall@gmail.com
          </a>
        </div>
      </div>
      <div className="mt-8 pt-8 border-t border-oyrial-muted/20 flex flex-col md:flex-row justify-between items-center text-xs text-oyrial-muted">
        <span>© 2026 Oyrial. All rights reserved.</span>
        <Link to="/admin/login" className="mt-4 md:mt-0 hover:text-oyrial-offwhite transition-colors uppercase tracking-widest no-underline">
          Admin Login
        </Link>
      </div>
    </div>
  </footer>
);

export default Footer;
