import { useEffect, useState, useRef } from "react";
import clockBase from "@/assets/user-clock-base.png";

const HeroClock = () => {
  const [time, setTime] = useState(new Date());
  const requestRef = useRef<number>();

  const updateClock = () => {
    setTime(new Date());
    requestRef.current = requestAnimationFrame(updateClock);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(updateClock);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const seconds = time.getSeconds() + time.getMilliseconds() / 1000;
  const minutes = time.getMinutes() + seconds / 60;
  const hours = (time.getHours() % 12) + minutes / 60;

  const hourRotation = hours * 30; // 360/12
  const minuteRotation = minutes * 6; // 360/60
  const secondRotation = seconds * 6; // 360/60

  return (
    <div className="relative w-full max-w-[450px] aspect-square mx-auto">
      {/* 
        The exact image provided by the user. 
        It naturally has the wood, epoxy, markers, logo, and 'Oyrial'.
        We use clip-path to ensure it's a perfect circle without any CSS borders or shadows giving it a 'shadow feeling'.
      */}
      <img 
        src={clockBase} 
        alt="Oyrial Custom Clock" 
        className="absolute inset-0 w-full h-full object-cover"
        style={{ clipPath: 'circle(49.5% at 50% 50%)' }}
      />

      {/* SVG Layer strictly for Live Hands */}
      <svg viewBox="0 0 100 100" className="absolute inset-0 w-full h-full z-20 pointer-events-none">
        <defs>
          <linearGradient id="brass-hand" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#D4AF37" />
            <stop offset="50%" stopColor="#CBA153" />
            <stop offset="100%" stopColor="#A67B38" />
          </linearGradient>

          {/* Very subtle shadow just so hands don't blend into the wood completely */}
          <filter id="hand-shadow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur in="SourceAlpha" stdDeviation="0.2" />
            <feOffset dx="0.5" dy="0.5" result="offsetblur" />
            <feComponentTransfer>
              <feFuncA type="linear" slope="0.3" />
            </feComponentTransfer>
            <feMerge>
              <feMergeNode />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Hour Hand */}
        <g transform={`rotate(${hourRotation} 50 50)`} filter="url(#hand-shadow)">
          <path
            d="M49 55 L49 28 L50 25 L51 28 L51 55 Z"
            fill="url(#brass-hand)"
          />
        </g>

        {/* Minute Hand */}
        <g transform={`rotate(${minuteRotation} 50 50)`} filter="url(#hand-shadow)">
          <path
            d="M49.3 55 L49.3 15 L50 12 L50.7 15 L50.7 55 Z"
            fill="url(#brass-hand)"
          />
        </g>

        {/* Second Hand */}
        <g transform={`rotate(${secondRotation} 50 50)`} filter="url(#hand-shadow)">
          <line
            x1="50"
            y1="60"
            x2="50"
            y2="10"
            stroke="#D4AF37"
            strokeWidth="0.5"
            strokeLinecap="round"
          />
          {/* Counterbalance for second hand */}
          <circle cx="50" cy="55" r="1.5" fill="#D4AF37" />
        </g>

        {/* Center Pin */}
        <circle cx="50" cy="50" r="2" fill="url(#brass-hand)" filter="url(#hand-shadow)" />
        <circle cx="50" cy="50" r="0.8" fill="#FFF" opacity="0.3" />
      </svg>
    </div>
  );
};

export default HeroClock;
