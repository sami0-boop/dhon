import { useState } from "react";
import { Navigate, Link, useLocation } from "react-router-dom";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingBag, 
  Image as ImageIcon, 
  Users, 
  Tag, 
  Truck, 
  Globe, 
  Settings, 
  Bell, 
  LogOut,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { useStore } from "@/context/StoreContext";

const AdminLayout = ({ children }: { children: React.ReactNode }) => {
  const { isAuthenticated, logout } = useStore();
  const location = useLocation();
  const [isCollapsed, setIsCollapsed] = useState(false);

  if (!isAuthenticated) {
    return <Navigate to="/admin/login" replace />;
  }

  const navLinks = [
    { name: "Overview", path: "/admin/overview", icon: LayoutDashboard },
    { name: "Orders", path: "/admin/orders", icon: ShoppingBag, badge: 3 },
    { name: "Products", path: "/admin/products", icon: Package },
    { name: "Media Library", path: "/admin/media", icon: ImageIcon },
    { name: "Customers", path: "/admin/customers", icon: Users },
    { name: "Discounts", path: "/admin/discounts", icon: Tag },
    { name: "Shipping Settings", path: "/admin/shipping", icon: Truck },
    { name: "Website Content", path: "/admin/content", icon: Globe },
    { name: "Store Settings", path: "/admin/settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-oyrial-offwhite flex font-sans text-oyrial-charcoal">
      {/* Sidebar */}
      <aside 
        className={`${isCollapsed ? "w-20" : "w-64"} bg-white border-r border-oyrial-charcoal/10 shadow-sm hidden md:flex flex-col transition-all duration-300 ease-in-out relative`}
      >
        <button 
          onClick={() => setIsCollapsed(!isCollapsed)}
          className="absolute -right-3 top-8 bg-white border border-oyrial-charcoal/10 rounded-full p-1 shadow-sm hover:shadow-md transition-shadow z-10 text-oyrial-charcoal"
        >
          {isCollapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>

        <div className={`p-6 flex items-center ${isCollapsed ? "justify-center" : "justify-between"}`}>
          <Link to="/" className="font-serif text-2xl tracking-wider text-oyrial-charcoal flex items-center">
            {isCollapsed ? "O" : (
              <>Oyrial<span className="text-[10px] font-sans tracking-normal ml-2 text-oyrial-muted uppercase bg-oyrial-grey px-2 py-0.5 rounded">Admin</span></>
            )}
          </Link>
        </div>
        
        <nav className="flex-1 px-3 mt-4 space-y-1.5 overflow-y-auto no-scrollbar pb-4">
          {navLinks.map((link) => {
            const isActive = location.pathname.startsWith(link.path);
            return (
              <Link
                key={link.name}
                to={link.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded text-sm tracking-wide transition-colors relative group ${
                  isActive 
                  ? "bg-oyrial-charcoal text-white shadow-sm" 
                  : "text-oyrial-muted hover:bg-oyrial-grey hover:text-oyrial-charcoal"
                }`}
                title={isCollapsed ? link.name : undefined}
              >
                <div className="flex-shrink-0 relative">
                  <link.icon size={18} />
                  {link.badge && (
                    <span className={`absolute -top-1.5 -right-1.5 flex h-3.5 w-3.5 items-center justify-center rounded-full text-[9px] ${isActive ? "bg-white text-oyrial-charcoal" : "bg-red-500 text-white"}`}>
                      {link.badge}
                    </span>
                  )}
                </div>
                {!isCollapsed && (
                  <span className="truncate">{link.name}</span>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="p-3 border-t border-oyrial-charcoal/10 space-y-1.5">
          <button
            className={`flex w-full items-center gap-3 px-3 py-2.5 rounded text-sm tracking-wide text-oyrial-muted hover:bg-oyrial-grey transition-colors ${isCollapsed ? "justify-center" : ""}`}
            title={isCollapsed ? "Notifications" : undefined}
          >
            <div className="relative">
              <Bell size={18} />
              <span className="absolute top-0 right-0 h-2 w-2 rounded-full bg-red-500 border border-white"></span>
            </div>
            {!isCollapsed && <span>Notifications</span>}
          </button>
          
          <button
            onClick={logout}
            className={`flex w-full items-center gap-3 px-3 py-2.5 rounded text-sm tracking-wide text-oyrial-muted hover:bg-red-50 hover:text-red-600 transition-colors ${isCollapsed ? "justify-center" : ""}`}
            title={isCollapsed ? "Logout" : undefined}
          >
            <LogOut size={18} />
            {!isCollapsed && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-x-hidden overflow-y-auto w-full">
        <div className="max-w-7xl mx-auto p-4 md:p-8 lg:p-12 animate-in fade-in duration-500 will-change-transform">
          {children}
        </div>
      </main>
    </div>
  );
};

export default AdminLayout;
