import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowUpRight, ArrowDownRight, Package, Users, ShoppingBag, Clock, AlertTriangle, Plus } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useStore } from "@/context/StoreContext";
import clock01 from "@/assets/clock-01.jpg";

const MOCK_CHART_DATA_7 = [
  { name: "Mon", revenue: 4000 },
  { name: "Tue", revenue: 3000 },
  { name: "Wed", revenue: 2000 },
  { name: "Thu", revenue: 2780 },
  { name: "Fri", revenue: 1890 },
  { name: "Sat", revenue: 2390 },
  { name: "Sun", revenue: 3490 },
];
const MOCK_CHART_DATA_30 = [
  { name: "1-5", revenue: 12000 },
  { name: "6-10", revenue: 15400 },
  { name: "11-15", revenue: 11000 },
  { name: "16-20", revenue: 8900 },
  { name: "21-25", revenue: 14200 },
  { name: "26-30", revenue: 18000 },
];

const AdminOverview = () => {
  const { orders, catalog } = useStore();
  const [chartPeriod, setChartPeriod] = useState<"7days" | "30days">("7days");

  const totalRevenue = orders.reduce((acc, curr) => curr.status !== "Cancelled" ? acc + curr.total : acc, 0);
  const pendingCount = orders.filter(o => o.status === "Processing").length;
  const deliveredCount = orders.filter(o => o.status === "Delivered").length;
  const lowStockItems = catalog.filter(i => !i.inStock);

  const StatusBadge = ({ status }: { status: string }) => {
    const colors = {
      Processing: "bg-amber-50 text-amber-700 border-amber-200",
      Shipped: "bg-blue-50 text-blue-700 border-blue-200",
      Delivered: "bg-green-50 text-green-700 border-green-200",
      Cancelled: "bg-red-50 text-red-700 border-red-200",
    }[status] || "bg-gray-50 text-gray-700 border-gray-200";
    
    return (
      <span className={`text-[10px] tracking-wider uppercase px-2 py-0.5 rounded-full border ${colors}`}>
        {status}
      </span>
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="font-serif text-4xl mb-1 text-oyrial-charcoal">Dashboard Overview</h1>
          <p className="text-sm text-oyrial-muted">Your store performance at a glance.</p>
        </div>
        <div className="flex gap-4">
          <Link 
            to="/admin/products" 
            className="flex items-center gap-2 px-6 py-3 bg-oyrial-charcoal text-white text-xs tracking-widest uppercase hover:bg-oyrial-black transition-colors shadow-sm"
          >
            <Plus size={16} /> Add Product
          </Link>
        </div>
      </header>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white p-6 border border-oyrial-charcoal/5 shadow-sm">
          <div className="flex justify-between items-start mb-4">
            <p className="text-xs tracking-widest text-oyrial-muted uppercase flex items-center gap-2">
              <ShoppingBag size={14} /> Total Revenue
            </p>
            <span className="flex items-center text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded">
              <ArrowUpRight size={12} className="mr-1" /> 12.5%
            </span>
          </div>
          <p className="font-serif text-3xl">৳ {totalRevenue.toLocaleString()}</p>
        </div>

        <div className="bg-white p-6 border border-oyrial-charcoal/5 shadow-sm">
           <div className="flex justify-between items-start mb-4">
            <p className="text-xs tracking-widest text-oyrial-muted uppercase flex items-center gap-2">
              <Package size={14} /> Total Orders
            </p>
            <span className="flex items-center text-xs text-green-600 bg-green-50 px-2 py-0.5 rounded">
              <ArrowUpRight size={12} className="mr-1" /> 8.2%
            </span>
          </div>
          <p className="font-serif text-3xl">{orders.length}</p>
        </div>

        <div className="bg-white p-6 border border-oyrial-charcoal/5 shadow-sm">
           <div className="flex justify-between items-start mb-4">
            <p className="text-xs tracking-widest text-oyrial-muted uppercase flex items-center gap-2">
               <Clock size={14} /> Pending / Delivered
            </p>
          </div>
          <p className="font-serif text-3xl">{pendingCount} <span className="text-oyrial-muted/30 mx-2">/</span> {deliveredCount}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Revenue Chart */}
        <div className="lg:col-span-2 bg-white p-6 border border-oyrial-charcoal/5 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h2 className="font-serif text-2xl text-oyrial-charcoal">Revenue Trend</h2>
            <div className="flex bg-oyrial-offwhite rounded p-1">
              <button 
                onClick={() => setChartPeriod("7days")}
                className={`text-xs px-3 py-1 rounded transition-colors ${chartPeriod === '7days' ? 'bg-white shadow-sm text-oyrial-charcoal' : 'text-oyrial-muted'}`}
              >
                7 Days
              </button>
              <button 
                onClick={() => setChartPeriod("30days")}
                className={`text-xs px-3 py-1 rounded transition-colors ${chartPeriod === '30days' ? 'bg-white shadow-sm text-oyrial-charcoal' : 'text-oyrial-muted'}`}
              >
                30 Days
              </button>
            </div>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartPeriod === '7days' ? MOCK_CHART_DATA_7 : MOCK_CHART_DATA_30}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E5E7EB" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12, fill: '#6B7280' }} dx={-10} tickFormatter={(val) => `৳${val}`} />
                <Tooltip 
                  contentStyle={{ border: 'none', borderRadius: '4px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  itemStyle={{ color: '#1F2937' }}
                />
                <Line type="monotone" dataKey="revenue" stroke="#1F2937" strokeWidth={2} dot={{ r: 4, fill: '#1F2937' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Top Products & Alerts */}
        <div className="space-y-6">
          <div className="bg-white p-6 border border-oyrial-charcoal/5 shadow-sm">
            <h2 className="font-serif text-2xl text-oyrial-charcoal mb-4">Top Selling</h2>
            <div className="flex items-center gap-4 p-3 hover:bg-oyrial-offwhite transition-colors rounded">
              <img src={clock01} alt="Clock" className="w-12 h-12 object-cover rounded" />
              <div className="flex-1">
                <p className="text-sm font-medium text-oyrial-charcoal">Oyrial No. 01</p>
                <p className="text-xs text-oyrial-muted">42 units sold</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium">৳ 105,000</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 border border-red-100 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-red-500"></div>
            <h2 className="font-serif text-2xl text-oyrial-charcoal mb-4 flex items-center gap-2">
              <AlertTriangle size={20} className="text-red-500" /> Low Stock
            </h2>
            {lowStockItems.length > 0 ? lowStockItems.map(item => (
              <div key={item.id} className="flex justify-between items-center py-2 border-b border-oyrial-charcoal/5 last:border-0">
                <p className="text-sm">{item.name}</p>
                <span className="text-xs font-medium text-red-600 bg-red-50 px-2 py-0.5 rounded">
                  Out of Stock
                </span>
              </div>
            )) : (
              <p className="text-sm text-oyrial-muted">Inventory levels are healthy.</p>
            )}
          </div>
        </div>
      </div>

      {/* Recent Orders Table */}
      <div className="bg-white p-6 border border-oyrial-charcoal/5 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-serif text-2xl text-oyrial-charcoal">Recent Orders</h2>
          <Link to="/admin/orders" className="text-xs tracking-widest uppercase text-oyrial-muted hover:text-oyrial-charcoal transition-colors">
            View All →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-oyrial-charcoal/5 text-[10px] tracking-widest text-oyrial-muted uppercase">
                <th className="pb-3 font-medium">Order ID</th>
                <th className="pb-3 font-medium">Customer</th>
                <th className="pb-3 font-medium">Date</th>
                <th className="pb-3 font-medium">Status</th>
                <th className="pb-3 font-medium text-right">Total</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {orders.slice(0, 5).map(order => (
                <tr key={order.id} className="border-b border-oyrial-charcoal/5 last:border-0 hover:bg-oyrial-offwhite/50 transition-colors group cursor-pointer">
                  <td className="py-4 font-medium group-hover:text-oyrial-charcoal/80">{order.id}</td>
                  <td className="py-4">{order.customerName}</td>
                  <td className="py-4 text-oyrial-muted">
                    {new Date(order.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                  </td>
                  <td className="py-4"><StatusBadge status={order.status} /></td>
                  <td className="py-4 text-right">৳ {order.total.toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdminOverview;
