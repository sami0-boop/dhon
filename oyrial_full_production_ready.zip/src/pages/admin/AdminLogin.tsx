import { useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { Eye, EyeOff, KeyRound, ArrowRight } from "lucide-react";
import { useStore } from "@/context/StoreContext";

const AdminLogin = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [error, setError] = useState(false);
  
  const { login, isAuthenticated } = useStore();
  const navigate = useNavigate();

  if (isAuthenticated) {
    return <Navigate to="/admin/overview" replace />;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (login(email, password)) {
      navigate("/admin/overview");
    } else {
      setError(true);
      setTimeout(() => setError(false), 3000);
    }
  };

  return (
    <div className="min-h-screen bg-oyrial-offwhite flex items-center justify-center p-4">
      <div className="w-full max-w-[420px] bg-white p-10 shadow-[0_8px_30px_rgb(0,0,0,0.04)] border border-oyrial-charcoal/5 flex flex-col">
        <div className="flex justify-center mb-8">
          <div className="w-12 h-12 rounded-full bg-oyrial-offwhite flex items-center justify-center text-oyrial-charcoal">
            <KeyRound size={20} />
          </div>
        </div>

        <div className="text-center mb-10">
          <h1 className="font-serif text-3xl text-oyrial-charcoal tracking-wide mb-2">Admin Portal</h1>
          <p className="text-sm text-oyrial-muted uppercase tracking-widest">Authorized Personnel Only</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-1">
            <label className="text-xs uppercase tracking-widest text-oyrial-charcoal font-medium">Email Address</label>
            <input
              type="email"
              placeholder="admin@brand.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-transparent border-b border-oyrial-charcoal/20 pb-2 pt-2 text-sm focus:outline-none focus:border-oyrial-charcoal transition-colors"
              required
            />
          </div>

          <div className="space-y-1 relative">
            <label className="text-xs uppercase tracking-widest text-oyrial-charcoal font-medium">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-transparent border-b border-oyrial-charcoal/20 pb-2 pt-2 text-sm focus:outline-none focus:border-oyrial-charcoal transition-colors tracking-widest"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-0 top-1/2 -translate-y-1/2 text-oyrial-muted hover:text-oyrial-charcoal transition-colors p-2"
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </button>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <label className="flex items-center gap-2 cursor-pointer group">
              <div className="relative flex items-center justify-center w-4 h-4 rounded border border-oyrial-charcoal/30 group-hover:border-oyrial-charcoal transition-colors">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="appearance-none absolute inset-0 w-full h-full cursor-pointer"
                />
                {rememberMe && <div className="w-2.5 h-2.5 bg-oyrial-charcoal rounded-sm" />}
              </div>
              <span className="text-xs tracking-wider text-oyrial-muted group-hover:text-oyrial-charcoal transition-colors">Remember me</span>
            </label>
            
            <a href="#" className="text-xs tracking-wider text-oyrial-muted hover:text-oyrial-charcoal transition-colors underline-offset-4 hover:underline">
              Forgot password?
            </a>
          </div>

          {error && (
            <div className="bg-red-50 text-red-600 text-xs tracking-wide py-3 px-4 rounded border border-red-100 flex items-center animate-in fade-in slide-in-from-top-2">
              Invalid email or password. Please try again.
            </div>
          )}

          <button
            type="submit"
            className="w-full mt-2 bg-oyrial-charcoal text-white hover:bg-oyrial-black transition-colors py-4 px-6 text-xs uppercase tracking-widest flex items-center justify-center gap-3 relative overflow-hidden group"
          >
            <span className="relative z-10 font-medium">Authenticate</span>
            <ArrowRight size={14} className="relative z-10 group-hover:translate-x-1 transition-transform" />
            <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out" />
          </button>
        </form>

        <div className="mt-8 pt-8 border-t border-oyrial-charcoal/10 text-center">
          <p className="text-[10px] text-oyrial-muted uppercase tracking-widest">
            Demo Credentials:<br/>
            <span className="text-oyrial-charcoal font-medium mt-1 inline-block select-all">admin@brand.com</span> / <span className="text-oyrial-charcoal font-medium select-all">admin123</span>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
