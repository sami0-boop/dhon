import { Search, Filter, Download, MoreHorizontal, X, Printer, CheckCircle, Package, Truck, XCircle, AlertCircle } from "lucide-react";
import { useStore, Order, OrderStatus } from "@/context/StoreContext";

const AdminOrders = () => {
  const { orders, updateOrderStatus } = useStore();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<OrderStatus | "All">("All");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  // Filtered orders
  const filteredOrders = orders.filter((order) => {
    const matchesSearch = order.id.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          order.customerName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "All" || order.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getStatusIcon = (status: OrderStatus) => {
    switch(status) {
      case "Processing": return <Package size={16} className="text-amber-600" />;
      case "Shipped": return <Truck size={16} className="text-blue-600" />;
      case "Delivered": return <CheckCircle size={16} className="text-green-600" />;
      case "Cancelled": return <XCircle size={16} className="text-red-600" />;
      default: return <AlertCircle size={16} />;
    }
  };

  const getStatusColor = (status: OrderStatus) => {
    switch(status) {
      case "Processing": return "bg-amber-50 text-amber-700 border-amber-200";
      case "Shipped": return "bg-blue-50 text-blue-700 border-blue-200";
      case "Delivered": return "bg-green-50 text-green-700 border-green-200";
      case "Cancelled": return "bg-red-50 text-red-700 border-red-200";
      default: return "bg-gray-50 text-gray-700 border-gray-200";
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500 relative">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-4xl mb-1 text-oyrial-charcoal">Orders</h1>
          <p className="text-sm text-oyrial-muted">Manage all customer purchases and fulfillment.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="flex items-center gap-2 px-4 py-2 border border-oyrial-charcoal/20 text-xs tracking-widest uppercase hover:bg-oyrial-offwhite transition-colors">
            <Download size={14} /> Export CSV
          </button>
        </div>
      </header>

      {/* Toolbar */}
      <div className="bg-white p-4 border border-oyrial-charcoal/5 shadow-sm flex flex-col md:flex-row gap-4 justify-between items-center">
        <div className="relative w-full md:w-96">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-oyrial-muted" />
          <input 
            type="text" 
            placeholder="Search order ID, customer name..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-sm border border-oyrial-charcoal/20 focus:outline-none focus:border-oyrial-charcoal transition-colors bg-transparent"
          />
        </div>
        <div className="flex items-center gap-4 w-full md:w-auto">
          <div className="flex items-center gap-2 text-sm text-oyrial-muted">
            <Filter size={16} /> Filter:
          </div>
          <select 
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as OrderStatus | "All")}
            className="px-4 py-2 text-sm border border-oyrial-charcoal/20 focus:outline-none appearance-none cursor-pointer bg-white"
          >
            <option value="All">All Statuses</option>
            <option value="Processing">Processing</option>
            <option value="Shipped">Shipped</option>
            <option value="Delivered">Delivered</option>
            <option value="Cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      {/* Orders Table */}
      <div className="bg-white border border-oyrial-charcoal/5 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="border-b border-oyrial-charcoal/5 text-[10px] tracking-widest text-oyrial-muted uppercase bg-oyrial-offwhite/30">
                <th className="p-4 font-medium">Order details</th>
                <th className="p-4 font-medium">Date</th>
                <th className="p-4 font-medium">Customer</th>
                <th className="p-4 font-medium">Status</th>
                <th className="p-4 font-medium text-right">Total</th>
                <th className="p-4 font-medium text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {filteredOrders.length > 0 ? filteredOrders.map(order => (
                <tr key={order.id} className="border-b border-oyrial-charcoal/5 hover:bg-oyrial-offwhite/50 transition-colors">
                  <td className="p-4 font-medium text-oyrial-charcoal cursor-pointer hover:underline" onClick={() => setSelectedOrder(order)}>
                    {order.id}
                    <div className="text-xs text-oyrial-muted mt-0.5 font-normal">
                      {order.items.length} item{order.items.length > 1 ? 's' : ''}
                    </div>
                  </td>
                  <td className="p-4 text-oyrial-muted">
                    {new Date(order.date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </td>
                  <td className="p-4">
                    {order.customerName}
                    <div className="text-xs text-oyrial-muted mt-0.5">{order.customerName.toLowerCase().replace(' ', '.')}@example.com</div>
                  </td>
                  <td className="p-4">
                     <span className={`inline-flex items-center gap-1.5 text-[10px] tracking-wider uppercase px-2.5 py-1 rounded-full border ${getStatusColor(order.status)}`}>
                        {getStatusIcon(order.status)}
                        {order.status}
                      </span>
                  </td>
                  <td className="p-4 text-right">৳ {order.total.toLocaleString()}</td>
                  <td className="p-4 text-center">
                    <button 
                      onClick={() => setSelectedOrder(order)}
                      className="p-2 text-oyrial-muted hover:text-oyrial-charcoal hover:bg-oyrial-grey rounded transition-colors"
                    >
                      <MoreHorizontal size={18} />
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={6} className="p-12 text-center text-oyrial-muted">
                    No orders found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Slide-over Modal for Order Details */}
      {selectedOrder && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div 
            className="absolute inset-0 bg-oyrial-black/20 backdrop-blur-sm transition-opacity" 
            onClick={() => setSelectedOrder(null)} 
          />
          <div className="w-full max-w-md bg-white h-full shadow-2xl relative z-10 animate-in slide-in-from-right duration-300 flex flex-col">
            <div className="p-6 border-b border-oyrial-charcoal/10 flex justify-between items-center bg-oyrial-offwhite/50">
              <h2 className="font-serif text-2xl">Order {selectedOrder.id}</h2>
              <button 
                onClick={() => setSelectedOrder(null)}
                className="p-2 text-oyrial-muted hover:text-oyrial-charcoal hover:bg-oyrial-grey rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="p-6 flex-1 overflow-y-auto space-y-8">
              {/* Status Manager */}
              <div className="space-y-3">
                <h3 className="text-xs tracking-widest uppercase text-oyrial-muted font-medium">Fulfillment Status</h3>
                <select 
                  value={selectedOrder.status}
                  onChange={(e) => updateOrderStatus(selectedOrder.id, e.target.value as OrderStatus)}
                  className={`w-full p-3 text-sm border font-medium focus:outline-none cursor-pointer appearance-none ${getStatusColor(selectedOrder.status)}`}
                >
                  <option value="Processing">Processing</option>
                  <option value="Shipped">Shipped</option>
                  <option value="Delivered">Delivered</option>
                  <option value="Cancelled">Cancelled</option>
                </select>
              </div>

              {/* Customer Info */}
              <div className="space-y-3">
                <h3 className="text-xs tracking-widest uppercase text-oyrial-muted font-medium">Customer Details</h3>
                <div className="bg-oyrial-offwhite p-4 border border-oyrial-charcoal/5 rounded text-sm space-y-2">
                  <p><strong className="font-medium">Name:</strong> {selectedOrder.customerName}</p>
                  <p><strong className="font-medium">Email:</strong> {selectedOrder.customerName.toLowerCase().replace(' ', '.')}@example.com</p>
                  <p><strong className="font-medium">Phone:</strong> +880 1234 567890</p>
                  <p><strong className="font-medium">Address:</strong> 123 Minimalist Ave, Dhaka, Bangladesh</p>
                </div>
              </div>

              {/* Order Items */}
              <div className="space-y-3">
                <h3 className="text-xs tracking-widest uppercase text-oyrial-muted font-medium">Order Items</h3>
                <div className="border border-oyrial-charcoal/10 rounded divide-y divide-oyrial-charcoal/10">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="p-4 flex justify-between items-center text-sm">
                      <div>
                        <p className="font-medium">{item.productName}</p>
                        <p className="text-xs text-oyrial-muted mt-1">Qty: {item.quantity}</p>
                      </div>
                      <p className="font-medium">৳ {selectedOrder.total.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-oyrial-charcoal/10 bg-oyrial-offwhite/50 flex gap-3">
              <button className="flex-1 flex items-center justify-center gap-2 py-3 bg-white border border-oyrial-charcoal/20 text-xs tracking-widest uppercase hover:bg-oyrial-grey transition-colors">
                <Printer size={16} /> Print Invoice
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminOrders;
