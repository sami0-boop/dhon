import { useState, useRef } from "react";
import { Plus, Search, Edit2, Trash2, X, Save, CheckCircle, Image as ImageIcon, Upload } from "lucide-react";
import { useStore } from "@/context/StoreContext";
import { Product } from "@/data/products";
import { toast } from "sonner";

const EMPTY_PRODUCT: Partial<Product> = {
  id: "",
  name: "",
  price: 0,
  description: "",
  shortDescription: "",
  image: "",
  size: "30cm",
  sizeCategory: "30cm",
  tier: "classic",
  inStock: true,
  features: [],
  specs: [],
};

const readFileAsDataURL = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

const AdminProducts = () => {
  const { catalog, updateProduct, addProduct, deleteProduct } = useStore();
  const [searchTerm, setSearchTerm] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Product>>({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newForm, setNewForm] = useState<Partial<Product>>(EMPTY_PRODUCT);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const newImageRef = useRef<HTMLInputElement>(null);
  const editImageRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (
    file: File,
    setter: (val: string) => void
  ) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Please select an image file (JPG, PNG, etc.)");
      return;
    }
    if (file.size > 5 * 1024 * 1024) {
      toast.error("Image is too large. Please use an image under 5MB.");
      return;
    }
    const dataUrl = await readFileAsDataURL(file);
    setter(dataUrl);
    toast.success("Image uploaded!");
  };

  const filteredCatalog = catalog.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const startEdit = (product: Product) => {
    setEditingId(product.id);
    setEditForm({ ...product });
    setShowAddForm(false);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditForm({});
  };

  const saveEdit = () => {
    if (!editForm.name || !editForm.price) {
      toast.error("Name and price are required");
      return;
    }
    updateProduct(editForm as Product);
    toast.success(`${editForm.name} updated!`);
    setEditingId(null);
    setEditForm({});
  };

  const confirmDelete = (id: string) => {
    const product = catalog.find(p => p.id === id);
    deleteProduct(id);
    toast.success(`${product?.name ?? "Product"} deleted`);
    setDeleteConfirmId(null);
  };

  const saveNewProduct = () => {
    if (!newForm.name || !newForm.price) {
      toast.error("Name and price are required");
      return;
    }
    const newProduct: Product = {
      ...(newForm as Product),
      id: `oyrial-${Date.now()}`,
      features: newForm.features || [],
      specs: newForm.specs || [],
    };
    addProduct(newProduct);
    toast.success(`${newProduct.name} added to catalog!`);
    setShowAddForm(false);
    setNewForm(EMPTY_PRODUCT);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      {/* Header */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="font-serif text-4xl mb-1 text-oyrial-charcoal">Products</h1>
          <p className="text-sm text-oyrial-muted">{catalog.length} items in catalog</p>
        </div>
        <button
          onClick={() => { setShowAddForm(!showAddForm); setEditingId(null); }}
          className="flex items-center gap-2 px-6 py-3 bg-oyrial-charcoal text-white text-sm tracking-widest uppercase hover:bg-black transition-colors"
        >
          {showAddForm ? <X size={16} /> : <Plus size={16} />}
          {showAddForm ? "Cancel" : "Add New Product"}
        </button>
      </header>

      {/* ADD PRODUCT FORM — inline, always visible when toggled */}
      {showAddForm && (
        <div className="bg-white border-2 border-oyrial-charcoal/20 p-6 space-y-4">
          <h2 className="font-serif text-2xl text-oyrial-charcoal border-b border-oyrial-charcoal/10 pb-3">
            New Product
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Product Name *</label>
              <input
                type="text"
                value={newForm.name || ""}
                onChange={e => setNewForm({ ...newForm, name: e.target.value })}
                placeholder="e.g. Oyrial No. 04"
                className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none focus:border-oyrial-charcoal"
              />
            </div>
            <div>
              <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Price (৳) *</label>
              <input
                type="number"
                value={newForm.price || ""}
                onChange={e => setNewForm({ ...newForm, price: Number(e.target.value) })}
                placeholder="e.g. 2500"
                className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none focus:border-oyrial-charcoal"
              />
            </div>
            {/* Image Upload - New Product */}
            <div className="md:col-span-2">
              <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-2">Product Photo</label>
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  ref={newImageRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={async e => {
                    const file = e.target.files?.[0];
                    if (file) await handleFileUpload(file, (val) => setNewForm(f => ({ ...f, image: val })));
                  }}
                />
                <button
                  type="button"
                  onClick={() => newImageRef.current?.click()}
                  className="flex items-center justify-center gap-2 px-5 py-3 border-2 border-dashed border-oyrial-charcoal/30 text-sm hover:border-oyrial-charcoal hover:bg-oyrial-offwhite transition-colors"
                >
                  <Upload size={16} /> Upload from Computer
                </button>
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-xs text-oyrial-muted">or paste a URL:</span>
                  <input
                    type="text"
                    value={typeof newForm.image === "string" && newForm.image.startsWith("data:") ? "(uploaded file)" : newForm.image || ""}
                    onChange={e => setNewForm({ ...newForm, image: e.target.value })}
                    placeholder="https://i.imgur.com/..."
                    className="flex-1 border border-oyrial-charcoal/20 px-3 py-2 text-sm focus:outline-none focus:border-oyrial-charcoal"
                  />
                </div>
              </div>
              {newForm.image && (
                <div className="mt-3 flex items-center gap-3">
                  <img src={newForm.image} alt="preview" className="w-20 h-20 object-cover rounded border border-oyrial-charcoal/20" onError={e => (e.currentTarget.style.display = "none")} />
                  <div>
                    <p className="text-xs text-green-700 font-medium">✓ Photo ready</p>
                    <button onClick={() => setNewForm({ ...newForm, image: "" })} className="text-xs text-red-500 hover:underline mt-1">Remove</button>
                  </div>
                </div>
              )}
            </div>
            <div>
              <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Short Description</label>
              <input
                type="text"
                value={newForm.shortDescription || ""}
                onChange={e => setNewForm({ ...newForm, shortDescription: e.target.value })}
                placeholder="e.g. Matte black. Silent. Bold."
                className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none focus:border-oyrial-charcoal"
              />
            </div>
            <div className="flex items-center gap-6">
              <div className="flex-1">
                <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Size</label>
                <select
                  value={newForm.sizeCategory || "30cm"}
                  onChange={e => setNewForm({ ...newForm, sizeCategory: e.target.value as any, size: e.target.value })}
                  className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none bg-white"
                >
                  <option value="30cm">30 cm</option>
                  <option value="40cm">40 cm</option>
                  <option value="custom">Custom</option>
                </select>
              </div>
              <div className="flex items-center gap-3 mt-5">
                <label className="text-sm font-medium text-oyrial-charcoal">In Stock</label>
                <button
                  type="button"
                  onClick={() => setNewForm({ ...newForm, inStock: !newForm.inStock })}
                  className={`w-12 h-6 rounded-full transition-colors relative ${newForm.inStock ? "bg-green-500" : "bg-gray-300"}`}
                >
                  <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${newForm.inStock ? "left-6" : "left-0.5"}`} />
                </button>
              </div>
            </div>
          </div>
          <div className="flex gap-3 pt-2">
            <button
              onClick={saveNewProduct}
              className="flex items-center gap-2 px-8 py-3 bg-oyrial-charcoal text-white text-sm tracking-widest uppercase hover:bg-black transition-colors"
            >
              <Save size={16} /> Save Product
            </button>
            <button
              onClick={() => { setShowAddForm(false); setNewForm(EMPTY_PRODUCT); }}
              className="px-6 py-3 border border-oyrial-charcoal/20 text-sm tracking-widest uppercase hover:bg-oyrial-offwhite transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="bg-white p-4 border border-oyrial-charcoal/5 shadow-sm flex items-center gap-3">
        <Search size={16} className="text-oyrial-muted flex-shrink-0" />
        <input
          type="text"
          placeholder="Search by product name..."
          value={searchTerm}
          onChange={e => setSearchTerm(e.target.value)}
          className="flex-1 text-sm focus:outline-none bg-transparent"
        />
        {searchTerm && (
          <button onClick={() => setSearchTerm("")} className="text-oyrial-muted hover:text-oyrial-charcoal">
            <X size={16} />
          </button>
        )}
      </div>

      {/* Product List */}
      <div className="space-y-3">
        {filteredCatalog.map((product) => (
          <div key={product.id} className="bg-white border border-oyrial-charcoal/5 shadow-sm overflow-hidden">
            {/* Product Row */}
            {editingId !== product.id ? (
              <div className="flex items-center gap-4 p-4">
                {/* Image */}
                <div className="flex-shrink-0 w-16 h-16 bg-oyrial-offwhite rounded overflow-hidden border border-oyrial-charcoal/10">
                  {product.image
                    ? <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                    : <div className="w-full h-full flex items-center justify-center"><ImageIcon size={20} className="text-oyrial-muted" /></div>
                  }
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="font-serif text-xl text-oyrial-charcoal truncate">{product.name}</p>
                  <p className="text-sm font-medium text-oyrial-charcoal mt-0.5">৳ {product.price.toLocaleString()}</p>
                </div>

                {/* Stock Badge */}
                <button
                  onClick={() => { updateProduct({ ...product, inStock: !product.inStock }); toast.success(`${product.name} → ${!product.inStock ? "In Stock" : "Out of Stock"}`); }}
                  className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-medium border transition-all hover:scale-105 ${product.inStock ? "bg-green-50 text-green-700 border-green-200 hover:bg-green-100" : "bg-red-50 text-red-700 border-red-200 hover:bg-red-100"}`}
                >
                  {product.inStock ? "✓ In Stock" : "✗ Out of Stock"}
                </button>

                {/* Actions */}
                <div className="flex-shrink-0 flex items-center gap-2">
                  <button
                    onClick={() => startEdit(product)}
                    className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 text-white text-xs tracking-wider rounded hover:bg-blue-700 transition-colors"
                  >
                    <Edit2 size={14} /> Edit
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(product.id)}
                    className="flex items-center gap-1.5 px-4 py-2 bg-red-600 text-white text-xs tracking-wider rounded hover:bg-red-700 transition-colors"
                  >
                    <Trash2 size={14} /> Delete
                  </button>
                </div>
              </div>
            ) : (
              /* INLINE EDIT FORM */
              <div className="p-6 border-t-4 border-blue-600 bg-blue-50/30 space-y-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="font-serif text-xl text-oyrial-charcoal flex items-center gap-2">
                    <Edit2 size={18} className="text-blue-600" /> Editing: {product.name}
                  </h3>
                  <button onClick={cancelEdit} className="p-2 text-oyrial-muted hover:text-oyrial-charcoal rounded-full hover:bg-oyrial-grey transition-colors">
                    <X size={18} />
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Product Name *</label>
                    <input
                      type="text"
                      value={editForm.name || ""}
                      onChange={e => setEditForm({ ...editForm, name: e.target.value })}
                      className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none focus:border-blue-500 bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Price (৳) *</label>
                    <input
                      type="number"
                      value={editForm.price || ""}
                      onChange={e => setEditForm({ ...editForm, price: Number(e.target.value) })}
                      className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none focus:border-blue-500 bg-white"
                    />
                  </div>

                  {/* Image Upload - Edit Product */}
                  <div className="md:col-span-2">
                    <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-2">Product Photo</label>
                    <div className="flex flex-col sm:flex-row gap-3">
                      <input
                        ref={editImageRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={async e => {
                          const file = e.target.files?.[0];
                          if (file) await handleFileUpload(file, (val) => setEditForm(f => ({ ...f, image: val })));
                        }}
                      />
                      <button
                        type="button"
                        onClick={() => editImageRef.current?.click()}
                        className="flex items-center justify-center gap-2 px-5 py-3 border-2 border-dashed border-blue-400 bg-blue-50 text-blue-700 text-sm hover:bg-blue-100 transition-colors"
                      >
                        <Upload size={16} /> Upload from Computer
                      </button>
                      <div className="flex items-center gap-2 flex-1">
                        <span className="text-xs text-oyrial-muted">or paste a URL:</span>
                        <input
                          type="text"
                          value={typeof editForm.image === "string" && editForm.image.startsWith("data:") ? "(uploaded file)" : editForm.image || ""}
                          onChange={e => setEditForm({ ...editForm, image: e.target.value })}
                          placeholder="https://i.imgur.com/your-image.jpg"
                          className="flex-1 border border-oyrial-charcoal/20 px-3 py-2 text-sm focus:outline-none focus:border-blue-500 bg-white"
                        />
                      </div>
                    </div>
                    {editForm.image && (
                      <div className="mt-3 flex items-center gap-3">
                        <img
                          src={editForm.image}
                          alt="preview"
                          className="w-20 h-20 object-cover rounded border border-oyrial-charcoal/20"
                          onError={e => (e.currentTarget.style.display = "none")}
                        />
                        <div>
                          <p className="text-xs text-green-700 font-medium">✓ Photo ready</p>
                          <button onClick={() => setEditForm({ ...editForm, image: "" })} className="text-xs text-red-500 hover:underline mt-1">Remove</button>
                        </div>
                      </div>
                    )}
                  </div>

                  <div>
                    <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Short Description</label>
                    <input
                      type="text"
                      value={editForm.shortDescription || ""}
                      onChange={e => setEditForm({ ...editForm, shortDescription: e.target.value })}
                      className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none focus:border-blue-500 bg-white"
                    />
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <label className="block text-xs tracking-widest uppercase text-oyrial-muted mb-1">Size</label>
                      <select
                        value={editForm.sizeCategory || "30cm"}
                        onChange={e => setEditForm({ ...editForm, sizeCategory: e.target.value as any, size: e.target.value })}
                        className="w-full border border-oyrial-charcoal/20 p-3 text-sm focus:outline-none bg-white"
                      >
                        <option value="30cm">30 cm</option>
                        <option value="40cm">40 cm</option>
                        <option value="custom">Custom</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2 mt-4">
                      <label className="text-sm font-medium whitespace-nowrap">In Stock</label>
                      <button
                        type="button"
                        onClick={() => setEditForm({ ...editForm, inStock: !editForm.inStock })}
                        className={`w-12 h-6 rounded-full transition-colors relative ${editForm.inStock ? "bg-green-500" : "bg-gray-300"}`}
                      >
                        <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform ${editForm.inStock ? "left-6" : "left-0.5"}`} />
                      </button>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-2 border-t border-oyrial-charcoal/10">
                  <button
                    onClick={saveEdit}
                    className="flex items-center gap-2 px-8 py-3 bg-green-600 text-white text-sm tracking-widest uppercase hover:bg-green-700 transition-colors"
                  >
                    <CheckCircle size={16} /> Save Changes
                  </button>
                  <button
                    onClick={cancelEdit}
                    className="px-6 py-3 border border-oyrial-charcoal/20 text-sm tracking-widest uppercase hover:bg-oyrial-offwhite transition-colors"
                  >
                    Discard
                  </button>
                </div>
              </div>
            )}

            {/* DELETE CONFIRM — inline banner */}
            {deleteConfirmId === product.id && (
              <div className="bg-red-50 border-t-2 border-red-500 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <p className="font-medium text-red-700">
                  Are you sure you want to delete <strong>{product.name}</strong>? This cannot be undone.
                </p>
                <div className="flex gap-3 flex-shrink-0">
                  <button
                    onClick={() => confirmDelete(product.id)}
                    className="px-5 py-2 bg-red-600 text-white text-sm font-medium rounded hover:bg-red-700 transition-colors"
                  >
                    Yes, Delete
                  </button>
                  <button
                    onClick={() => setDeleteConfirmId(null)}
                    className="px-5 py-2 border border-red-300 text-red-600 text-sm rounded hover:bg-red-100 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        ))}

        {filteredCatalog.length === 0 && (
          <div className="bg-white p-16 text-center border border-oyrial-charcoal/5">
            <p className="text-oyrial-muted">No products found.</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminProducts;
