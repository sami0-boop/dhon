import { useEffect } from "react";
import { useLocation } from "react-router-dom";

export function useSectionReveal() {
  const location = useLocation();

  useEffect(() => {
    // Use a small timeout to allow React to mount the DOM elements completely after route change
    const timeout = setTimeout(() => {
      const sections = document.querySelectorAll('section');
      
      sections.forEach(section => {
        if (!section.classList.contains('reveal-observed')) {
          section.classList.add('reveal-ready');
          section.classList.add('reveal-observed');
        }
      });

      const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            entry.target.classList.add('reveal-visible');
            // We unobserve so the animation only happens once per page load to remain minimal and non-distracting
            observer.unobserve(entry.target); 
          }
        });
      }, { 
        threshold: 0.1, // Trigger when 10% of the section is visible
        rootMargin: "0px 0px -50px 0px" // Slightly wait until it comes up
      });

      sections.forEach(s => observer.observe(s));

      return () => observer.disconnect();
    }, 100);

    return () => clearTimeout(timeout);
  }, [location.pathname]);
}
