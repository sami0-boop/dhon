# Oyrial — Time Gone Wild

Premium minimalist wall clocks, handcrafted in Bangladesh.

## Tech Stack

- React 18 + TypeScript
- Vite
- Tailwind CSS
- shadcn/ui
- React Router

## Getting Started

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```
